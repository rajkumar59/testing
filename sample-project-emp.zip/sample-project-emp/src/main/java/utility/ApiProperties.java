package utility;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

	public class ApiProperties {
		
		public static String getProperty(String name) throws IOException {
			Properties prop = new Properties();
			prop.load(new FileInputStream("config.properties"));
			return prop.getProperty(name);
			
		}
		
	    
	}
