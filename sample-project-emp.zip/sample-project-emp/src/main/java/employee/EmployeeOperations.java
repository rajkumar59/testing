package employee;

import java.io.IOException;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static io.restassured.RestAssured.given;
import utility.ApiProperties;

public class EmployeeOperations {
	
	
	
	 public Response getSingleEmployee(String empId) throws IOException {
		
		 String uri = ApiProperties.getProperty("get.single.employee");
		 RestAssured.baseURI = uri;
		 
			 
		 return given().relaxedHTTPSValidation()
		 .when()
		 .get("/employee/"+empId);
		 
		
		
	 }
	 
	 public Response deleteEmployee(String empId) throws IOException {
			
		 String uri = ApiProperties.getProperty("delete.employee");
		 RestAssured.baseURI = uri;
		 
		 return given().relaxedHTTPSValidation()
		 .when()
		 .delete("/delete/"+empId);
		  
		
		
	 }
   
}
