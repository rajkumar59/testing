package test;

import java.io.IOException;
import employee.EmployeeOperations;
import io.restassured.response.Response;
import static org.junit.Assert.assertTrue;

public class TestEmployee {
	
	public static void main(String[] args) throws IOException {
	    
		//GET method
		String empId = "1";
		EmployeeOperations emp = new EmployeeOperations();
		Response singleEmpResp = emp.getSingleEmployee(empId);
		
		//GET call - successful status code check
		singleEmpResp.then().assertThat().statusCode(200);
		
		//Return specific emp details - checking emp id in the response
		String aempId = singleEmpResp.jsonPath().getString("data.id");
		assertTrue("Verify employee id: ", empId.equals(aempId));
		
		//DELETE method
		Response deleteEmpResp = emp.deleteEmployee(empId);
		
		//DEETE call - successful status code check
		deleteEmpResp.then().assertThat().statusCode(200);
		
		//verify DELETE message
		String message = deleteEmpResp.jsonPath().getString("message");
		assertTrue("Verify successful message after deleting the record: ", "Successfully! Record has been deleted".equals(message));
		
		
		
	}

}
