package searchitem;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pagefactory.HomePage;
import pagefactory.AddToCartPage;
import pagefactory.ShippingCartPage;

import static org.junit.Assert.assertTrue;

import utilities.AppUtility;
import utilities.ApplicationVariables;


public class BuyingABook {
	
	static WebDriver driver;
	static AppUtility amazon = new AppUtility();
	
	public static void main(String[] args) throws IOException {
		
		
		String browser = ApplicationVariables.getProperty("browser");
		String appURL = ApplicationVariables.getProperty("app.url.amazon");
		String searhItemName = ApplicationVariables.getProperty("search.item.amazon");
		
		//step1 visit amazon
		driver = amazon.launchApp(browser,appURL);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		HomePage home = PageFactory.initElements(driver, HomePage.class);
		
		//step2 search for "qa testing for beginners" book
		home.searchItem(searhItemName);
		
		//Step3 capture price and select first item
		String fItemPrice = home.getFirstItemPrice();
		System.out.println("prince in step3: "+fItemPrice);
		home.selectFirstItem();
		
		//Step4 assert the price with step3
		AddToCartPage screen2 = PageFactory.initElements(driver, AddToCartPage.class);
		String priceInItemScreen = screen2.getPriceItemScreen();
		System.out.println("prince in step4: "+fItemPrice);
		
		assertTrue("Verify price in item screen", fItemPrice.equals(priceInItemScreen));
		
		//add an item into card
		screen2.addItemToCard();

		//assert the price with step3 before checkout
		ShippingCartPage shippingCart = PageFactory.initElements(driver, ShippingCartPage.class);
		String shippingCartPrice = shippingCart.getPriceShippingCart();
		System.out.println("prince before checkout: "+shippingCartPrice);
		assertTrue("Verify price in shipping cart", fItemPrice.equals(shippingCartPrice));
		
		
		//proceed to checkout
		shippingCart.proceedToCheckOut();
		
		//step5 assert requires a login
		//so it can be done after login , assert same like above step, (so skipping this step due login)
		
		driver.quit();
	
	}
	
	
	
	
}
