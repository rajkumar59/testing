package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ShippingCartPage {
	
	@FindBy(id = "hlb-ptc-btn-native")
	WebElement proceedToCheckout;
	
	@FindBy(xpath = "//*[@id='hlb-subcart']//span[contains(@class,'hlb-price')]")
	WebElement cartSubTotal;
	
	WebDriver driver;
	
	public ShippingCartPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getPriceShippingCart() {
		return cartSubTotal.getText();
	}
	
	public void proceedToCheckOut() {
		proceedToCheckout.click();
	}

}
