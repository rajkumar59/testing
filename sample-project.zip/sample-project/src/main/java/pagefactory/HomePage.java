package pagefactory;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage  {

	
	@FindBy(id = "twotabsearchtextbox")
	WebElement searchBox;
	
	@FindBy(xpath="//div[@data-cel-widget='search_result_1']//h2/a")
	WebElement firstItemlnk;
	
	@FindBy(xpath="//div[@data-cel-widget='search_result_1']//span[@class='a-price']//span[@class='a-price-symbol']")
	WebElement priceSymbol;
	
	@FindBy(xpath="//div[@data-cel-widget='search_result_1']//span[@class='a-price']//span[@class='a-price-whole']")
	WebElement priceWhole;
	

	@FindBy(xpath="//div[@data-cel-widget='search_result_1']//span[@class='a-price']//span[@class='a-price-fraction']")
	WebElement priceFraction;
	
	
	
	WebDriver driver;
	

	public HomePage(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public void searchItem(String itemname) {
		searchBox.sendKeys(itemname);
		searchBox.sendKeys(Keys.ENTER);
		
		
	}
	
	public void selectFirstItem() {
		firstItemlnk.click();
		
	}
	
	public String getFirstItemPrice() {
		return priceSymbol.getText()+priceWhole.getText()+"."+priceFraction.getText();
		
		
	}
	
	
}
