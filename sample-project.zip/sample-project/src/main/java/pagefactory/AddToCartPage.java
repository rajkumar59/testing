package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddToCartPage {
	
	@FindBy(id = "newBuyBoxPrice")
	WebElement priceInItemScreen;
	
	@FindBy(id = "submit.add-to-cart")
	WebElement addToCart;
	
	WebDriver driver;
	
	public AddToCartPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getPriceItemScreen() {
		return priceInItemScreen.getText();
	}
	
	public void addItemToCard() {
		addToCart.click();
	}

}
