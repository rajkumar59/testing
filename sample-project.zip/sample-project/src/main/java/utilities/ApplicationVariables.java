package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ApplicationVariables {
	
	public static String getProperty(String name) throws IOException {
		Properties prop = new Properties();
		prop.load(new FileInputStream("app.properties"));
		return prop.getProperty(name);
		
	}
	
    
}
