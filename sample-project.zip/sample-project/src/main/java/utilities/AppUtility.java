package utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AppUtility {
	
	WebDriver driver;
	
	public WebDriver launchApp(String browser, String url) throws IOException {
		
		if(browser.equalsIgnoreCase("chrome")) {
			 System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/lib/chromedriver.exe");
			 driver = new ChromeDriver();
	    }

		driver.get(url);
		driver.manage().window().maximize();
		return driver;
	}

}
