package utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class CustomDriver {

	private static WebDriver  driver;

	public static WebDriver getDriver() throws IOException {
			if(ApplicationVariables.getProperty("browser").equalsIgnoreCase("chrome")) {
		   System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/lib/chromedriver.exe");
		   driver = new ChromeDriver();
		}
		return driver;
	}
	
	

}
